const imagePaths = {
    logo: require('../../images/logflow-logo.png'),
    logo2: require('../../images/logflow-logo-mark.png'),
    key: require('../../images/door-key.png'),
    booking: require('../../images/booking.png'),
    visitor: require('../../images/user.png'),
    addroom: require('../../images/plus.png'),
    logout: require('../../images/log-out.png'),
    heroimg: require('../../images/Signup-login-img.svg'),

};
  
  export default imagePaths;